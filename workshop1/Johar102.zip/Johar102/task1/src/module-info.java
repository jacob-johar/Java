module task1 {
}